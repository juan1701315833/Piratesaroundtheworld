/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import javax.swing.ImageIcon;

/**
 *
 * @author paca_
 */
public class Background {
 
    private int posX;
    private int posY;
    private int width;
    private int height;
    private ImageIcon ImageBackground;

    public Background() {
    }

    public Background(int posX, int posY, int width, int height, ImageIcon ImageBackground) {
        this.posX = posX;
        this.posY = posY;
        this.width = width;
        this.height = height;
        this.ImageBackground =  ImageBackground;   
    }

    /**
     * @return the posX
     */
    public int getPosX() {
        return posX;
    }

    /**
     * @param posX the posX to set
     */
    public void setPosX(int posX) {
        this.posX = posX;
    }

    /**
     * @return the posY
     */
    public int getPosY() {
        return posY;
    }

    /**
     * @param posY the posY to set
     */
    public void setPosY(int posY) {
        this.posY = posY;
    }

    /**
     * @return the width
     */
    public int getWidth() {
        return width;
    }

    /**
     * @param width the width to set
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * @return the height
     */
    public int getHeight() {
        return height;
    }

    /**
     * @param height the height to set
     */
    public void setHeight(int height) {
        this.height = height;
    }

    /**
     * @return the ImageBackground
     */
    public ImageIcon getImageBackground() {
        return ImageBackground;
    }

    /**
     * @param ImageBackground the ImageBackground to set
     */
    public void setImageBackground(ImageIcon ImageBackground) {
        this.ImageBackground = ImageBackground;
    }
    
    
    

}
